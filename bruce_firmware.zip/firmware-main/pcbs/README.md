# Bruce PCBs

Here are some of the open-source community made PCBs, you can download them and print whenever you want to OR you can order directly with our sponsor PCBWAY just by clicking on the banner above:
## Order here
[![PCB from PCBWay](https://www.pcbway.com/project/img/images/frompcbway-1220.png)](https://www.pcbway.com/project/shareproject/Bruce_PCB_Smoochiee_d6a0284b.html)

## Bruce PCB from Smoochiee:

![Bruce PCB v2](https://raw.githubusercontent.com/pr3y/Bruce/refs/heads/main/media/pcbs/smoochie/Bruce_PCB_full.png)
![Bruce PCB back](https://raw.githubusercontent.com/pr3y/Bruce/refs/heads/main/media/pcbs/smoochie/back.png)
![Bruce PCB front](https://raw.githubusercontent.com/pr3y/Bruce/refs/heads/main/media/pcbs/smoochie/front.png)

## Bruce PBC for StickCPlus 1.1 and 2 from Pirata
![StickCPlus PCB front](https://raw.githubusercontent.com/pr3y/Bruce/refs/heads/main/media/pcbs/Pirata/front.png)
![StickCPlus PCB back](https://raw.githubusercontent.com/pr3y/Bruce/refs/heads/main/media/pcbs/Pirata/back.png)
