# Bruce M5 Stick Extender

This PCB was designed by ultramarines

![ultramarines Bruce PCB side](https://raw.githubusercontent.com/pr3y/Bruce/refs/heads/main/media/pcbs/ultramarines/ultramarines_full_side.jpg)
![ultramarines Bruce PCB front](https://raw.githubusercontent.com/pr3y/Bruce/refs/heads/main/media/pcbs/ultramarines/ultramarines_pcb_front.png)
![ultramarines Bruce PCB back](https://raw.githubusercontent.com/pr3y/Bruce/refs/heads/main/media/pcbs/ultramarines/ultramarines_pcb_back.jpg)
