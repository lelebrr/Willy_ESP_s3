# Smoochiee 3d Case Design

![Bruce 3d Case](https://raw.githubusercontent.com/pr3y/Bruce/refs/heads/main/media/pictures/3d_case_parts.png)

This PCB and case was designed by Smoochiee

Source files to print are on the .zip on this directory "Bruce_PCB_V2_3dCase.zip"

IF YOU LIKE SMOOCHIEE'S PROJECT PLEASE CONSIDER DONATING TO HIS PAYPAL..ANY DONATION WILL BE USE FOR PCB AND TESTING OTHER MODULES

https://www.paypal.com/paypalme/smoochieelee?country.x=PH&locale.x=en_US
