# Bruce PCB V2

This PCB was designed by Smoochiee

IF YOU LIKE SMOOCHIEE'S PROJECT PLEASE CONSIDER DONATING TO HIS PAYPAL..ANY DONATION WILL BE USE FOR PCB AND TESTING OTHER MODULES

https://www.paypal.com/paypalme/smoochieelee?country.x=PH&locale.x=en_US
