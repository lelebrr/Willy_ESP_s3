# Connections

## RC522

### Via SPI

![RC522 M5 Stick RC522 via SPI](rc522_stick_spi.jpg)

### Via I2C

Connecting a RC522 via I2C needs a board mod to work.

More information can be found here: https://forum.arduino.cc/t/rc522-rfid-rc522-switching-spi-to-uart-interface-or-i2c-possible/425741

![RC522 M5 Stick RC522 via I2C](rc522_stick_i2c_needs_board_mod_see_readme.jpg)

